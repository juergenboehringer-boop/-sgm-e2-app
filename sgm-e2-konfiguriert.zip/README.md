# SGM Aufheim/Holzschwang E2

## 1. Firebase
1. https://console.firebase.google.com öffnen, Projekt anlegen (z.B. sgm-e2-team).
2. Projektübersicht > Web-App hinzufügen (`</>`). Die Firebase-Konfiguration ist bereits in `public/index.html` eingetragen.
3. Build > Firestore Database > Datenbank erstellen. Region auswählen. Unter Regeln Inhalt aus `firestore.rules` einfügen und veröffentlichen. Alternativ Regeln mit CLI deployen.
4. Build > Authentication > Sign-in method > E-Mail/Passwort aktivieren. Unter Users Trainer-Benutzer anlegen. Die UID jedes Trainers kopieren.
5. Firestore > Daten > Sammlung `trainers` anlegen, Dokument-ID exakt die UID des Trainers, Feld `name` (string) hinzufügen. Nur Projektadministratoren können dies in der Konsole tun.

## 2. Veröffentlichen
1. Node.js installieren: https://nodejs.org/
2. Im Terminal im Ordner dieses Projekts `npm install -g firebase-tools` ausführen.
3. `firebase login` und `firebase use --add` ausführen, das Firebase-Projekt `sgm-aufheim-holzschwan-e2` auswählen.
4. `firebase deploy --only hosting,firestore:rules` ausführen.
5. Die angezeigte Hosting-URL mit den Eltern teilen.

## Wichtig
- Eltern benötigen keinen Login. Nur freigeschaltete Trainer sehen Bearbeitungsformulare und dürfen schreiben.
- Termine und Tabelle werden manuell gepflegt, nicht automatisch mit BFV synchronisiert.
- Tabellenplatz wird nach Punkten, Tordifferenz und erzielten Toren berechnet; die offiziellen BFV-Regeln können abweichen.
- Keine persönlichen Kinderdaten eintragen. Öffentliche Leserechte bedeuten, dass alle Besucher der URL die Daten sehen können.
- Trainer können neue Spiele anlegen und Tabelleneinträge aktualisieren. Bestehende Spiele bearbeiten/löschen ist in dieser ersten Version noch nicht umgesetzt.
- Kosten und Freikontingente im Firebase-Projekt prüfen.
